// ~~ double tilde operator

let a =3.6
let result = ~~a
console.log(result)