class Area{

constructor(height,width){

    this.height=height,
    this.width=width
}

Rectangle=()=>{

return this.height*this.width
    
}




}


let obj=new Area(5,6)
console.log(obj.Rectangle())

