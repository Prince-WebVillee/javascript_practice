let person =require("./person")
console.log(person)