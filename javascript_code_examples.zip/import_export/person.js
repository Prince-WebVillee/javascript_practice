 let person = {


    name:"john",
    age:24
}

module.exports = person