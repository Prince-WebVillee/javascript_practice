console.log(9-"4")
console.log("9"-4)
//type conversion
console.log("9"*4)
