
let sum=(x)=>{
return (y)=>{
return x+y

}


}


console.log(sum(10,20))