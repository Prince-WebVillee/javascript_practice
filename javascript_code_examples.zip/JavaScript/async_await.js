let getName =async ()=>{
let  result = await "hello"
console.log(result)

    
}
getName()
console.log("hello1")
console.log("hello2")