var counter =0;

const incrementCount=()=>{
    console.log(counter++)
}

setInterval(incrementCount,1000)