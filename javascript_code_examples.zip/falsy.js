//1.

// if(0)
// console.log("true")
// else
// console.log("false")

/*************************************************************** */

//2. 

// if(null)
// console.log("true")
// else
// console.log("false")

/************************************************************** */

//3.

// if(undefined)
// console.log("true")
// else
// console.log("false")

/************************************************************ */

//4.

// if(false)
// console.log("true")
// else 
// console.log("false")

/*********************************************************** */

//5. 

// if(NaN)
// console.log("true")
// else
// console.log("false")


/********************************************************** */

//6 

// if("")
// console.log("true")
// else
// console.log("false")