let person ={


    name:"xyz",
    a:function(){

        console.log(this.name)
    }



}

console.log(person.a());