// function Person(name,age,address){


//     this.name=name,
//     this.age=age,
//     this.address=address



// }

// let allperson=[]

// let person=new Person("john",24,"x street")
// let person1=new Person("john1",25,"x street1")
// let person2=new Person("john2",26,"x street2")
// let person3=new Person("john3",27,"x street3")

// allperson.push(person,person1,person2,person3)
// console.log(allperson)

/*************************************************************************/


class Person{

constructor(name,age,address){

    this.name=name;
    this.age=age;
    this.address=address

}

}


let obj =new Person("abc",24,"indore")


console.log(obj)