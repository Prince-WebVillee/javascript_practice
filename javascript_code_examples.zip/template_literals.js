let a =`hello`
console.log(`Value of a : ${a}`)

