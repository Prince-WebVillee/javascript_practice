//iify => immediately invoked function it gets invoked just after the declaration

(()=>{

console.log("hello")


})
()


