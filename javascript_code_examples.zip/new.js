let a =20;
let a=30;
console.log(a)
//output : identifier 'a' has already been declared

// var a=30;
// var a=40;
// console.log(a)
// output : 40


a=(2,3,5)
console.log(a)