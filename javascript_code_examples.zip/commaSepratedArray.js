let arr=["english","maths","science"]

console.log(arr.join())