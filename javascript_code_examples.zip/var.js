// let a;
// console.log(a)
// a=10
//output : undefined

/********************************************************************* */

// var a;
// console.log(a)
// a=5;
//output : undefined

/******************************************************************* */

// a=10;
// console.log(a)
//output : 10

/******************************************************************** */

// a=10
// console.log(a)
// var a
// output: 10

/******************************************************************* */

// var a=10;
// console.log(a)
// const changeValue=()=>{


//   var   a=20

   
// }
// changeValue()
// console.log(a)






// let a =10
// console.log(a)
// const changeValue=()=>{

//   let  a=30;
//   console.log(a)
// }

// changeValue()
// console.log(a)