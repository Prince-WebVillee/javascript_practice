//exmaple 1

// console.log(x);
//     var x = 6;
//     console.log(x);

/********************************************************** */

//example 2

console.log(x);
    console.log(z);
    var x = 6;
    let z = 6;
    console.log(x);
    console.log(z);


