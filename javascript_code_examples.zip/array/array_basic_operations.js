let fruits= ["banana","apple","mango"]
console.log(fruits)
//push an element in array
//push will insert new element at the end of an array
fruits.push("pear")
console.log(fruits)

//pop an element from an array
//pop will remove last element of an array

fruits.pop()
console.log(fruits)


//shift 

fruits.shift()
console.log(fruits)

//unshift

fruits.unshift("pear")
console.log(fruits)