/*An array is a special variable, which can hold more than one value of different types.
it may be number,string,function,objects..
array is an objects
*/

let arr = [0,1,2,3,4,5,6]
console.log(arr)

let movies = ["avengers","spiderman","justice league", "ironman"]
console.log(movies)
console.log(typeof movies)

const cars = ()=>{

    return movies[0]
}

let newArr= [Date.now(),cars()]
console.log(newArr)


/****************looping in array **************************/


