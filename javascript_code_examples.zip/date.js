let date=new Date()
// console.log(date)
// console.log(date.toUTCString())
// console.log(date.getTimezoneOffset())
// console.log(date.getMilliseconds())
// console.log(date.getTime())
// console.log(date.toLocaleString())
// console.log(date.toLocaleTimeString())
// console.log(date.getUTCDay())
// console.log(date.toString())
// console.log(date.getFullYear())
// let newDate=new Date(2022,11,20,02,23,34)
// console.log(newDate)


// console.log(date.toLocaleTimeString())


console.log(date.getMinutes()+10)