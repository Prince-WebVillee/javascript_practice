//example 1

// let sum=(a)=>{
//     return (b)=>{
        
//         return a+b
//     }
    
    
// }

// console.log(sum(5)(6))


/************************************************************ */

//example 2

let mul=(a)=>{

    return (b)=>{

        return (c)=>{
return a*b*c

        }
    }



}

console.log(mul(2)(3)(4))