function Person (){

this.name="xyz",
this.age=24,
this.address="abc"


}


let person = new Person()

console.log(person.name)