let arr=[1,[2,[3]]]

console.log(arr.flat(2))