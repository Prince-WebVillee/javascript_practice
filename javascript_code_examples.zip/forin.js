let arr=[1,2,3,4,5,6]

for(let value in arr){
let i=0
console.log(`index : ${value[i]} => value : ${arr[value]}`)

}