let a = function(){

    console.log(" I am A function")
}
a()