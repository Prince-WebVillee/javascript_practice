a=20
try{

if(a==10)
throw new Error("cant use value of a=10")

}

catch(e){

console.log(e)

}