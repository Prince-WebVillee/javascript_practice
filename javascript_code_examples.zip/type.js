var a="hello"
var b=2
console.log(typeof null)
console.log(typeof undefined)
console.log(typeof b)
console.log(typeof  Number)
console.log(typeof typeof a)
console.log(typeof typeof b)
console.log(typeof typeof null)
console.log(typeof typeof 2)
console.log(typeof BigInt)
console.log(typeof this)
console.log(typeof 4)
console.log(typeof NaN)
console.log(null == undefined)
let n =null
console.log(n)

console.log(typeof {})