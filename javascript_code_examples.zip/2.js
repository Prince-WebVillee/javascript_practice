const  a=b=3
console.log(b)
console.log(a)

