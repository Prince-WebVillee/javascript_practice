let square=(x)=>{
    
    return x=x*x
    
}


let y=10;

console.log(square(y))
console.log(y)
