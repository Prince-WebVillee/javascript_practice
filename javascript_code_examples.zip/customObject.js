let person = new Object()
console.log(person)
person.name="john",
person.age=24,
person.address="indore"

console.log(person)